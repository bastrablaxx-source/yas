(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/kelontongv2_src_bdb51c1f._.js",
  "static/chunks/55a14_next_bd37468f._.js"
],
    source: "dynamic"
});
