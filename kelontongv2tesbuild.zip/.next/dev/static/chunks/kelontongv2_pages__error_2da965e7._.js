(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/55a14_next_dist_compiled_0523ca9b._.js",
  "static/chunks/55a14_next_dist_shared_lib_48955c90._.js",
  "static/chunks/55a14_next_dist_client_65683a71._.js",
  "static/chunks/55a14_next_dist_34b6a2bf._.js",
  "static/chunks/55a14_next_error_13cf9fbc.js",
  "static/chunks/[next]_entry_page-loader_ts_cdc039d1._.js",
  "static/chunks/55a14_react-dom_18379728._.js",
  "static/chunks/55a14_12d2d743._.js",
  "static/chunks/[root-of-the-server]__45939bf3._.js"
],
    source: "entry"
});
