(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a5d2188b._.js",
  "static/chunks/55a14_next_dist_compiled_react-dom_d906132b._.js",
  "static/chunks/55a14_next_dist_compiled_react-server-dom-turbopack_0e20b1b5._.js",
  "static/chunks/55a14_next_dist_compiled_next-devtools_index_435c3c2e.js",
  "static/chunks/55a14_next_dist_compiled_9d50e3f9._.js",
  "static/chunks/55a14_next_dist_client_d69053b3._.js",
  "static/chunks/55a14_next_dist_d6dc495c._.js",
  "static/chunks/55a14_@swc_helpers_cjs_1712d2af._.js"
],
    source: "entry"
});
