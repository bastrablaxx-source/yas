var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/55a14_c42f2f05._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/kelontongv2/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/kelontongv2/node_modules/next/document.js [ssr] (ecmascript)").exports
