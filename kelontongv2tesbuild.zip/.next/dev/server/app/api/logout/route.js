var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/logout/route.js")
R.c("server/chunks/55a14_a8885c52._.js")
R.c("server/chunks/[root-of-the-server]__68c90a91._.js")
R.c("server/chunks/kelontongv2__next-internal_server_app_api_logout_route_actions_5ed7e6ad.js")
R.m("[project]/kelontongv2/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/kelontongv2/src/app/api/logout/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/kelontongv2/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/kelontongv2/src/app/api/logout/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
