module.exports = [
"[project]/kelontongv2/.next-internal/server/app/dashboard/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_dashboard_page_actions_47ae2aa1.js.map