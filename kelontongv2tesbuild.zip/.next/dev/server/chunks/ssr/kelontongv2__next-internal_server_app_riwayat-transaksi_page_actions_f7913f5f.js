module.exports = [
"[project]/kelontongv2/.next-internal/server/app/riwayat-transaksi/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_riwayat-transaksi_page_actions_f7913f5f.js.map