module.exports = [
"[project]/kelontongv2/.next-internal/server/app/barang/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_barang_page_actions_b6c8bd51.js.map