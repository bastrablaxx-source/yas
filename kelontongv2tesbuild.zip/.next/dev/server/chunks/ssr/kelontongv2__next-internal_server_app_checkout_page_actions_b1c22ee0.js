module.exports = [
"[project]/kelontongv2/.next-internal/server/app/checkout/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_checkout_page_actions_b1c22ee0.js.map