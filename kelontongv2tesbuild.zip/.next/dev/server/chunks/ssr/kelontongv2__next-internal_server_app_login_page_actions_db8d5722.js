module.exports = [
"[project]/kelontongv2/.next-internal/server/app/login/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_login_page_actions_db8d5722.js.map