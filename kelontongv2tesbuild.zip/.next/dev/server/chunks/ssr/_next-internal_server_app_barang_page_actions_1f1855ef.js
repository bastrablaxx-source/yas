module.exports = [
"[project]/.next-internal/server/app/barang/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_barang_page_actions_1f1855ef.js.map