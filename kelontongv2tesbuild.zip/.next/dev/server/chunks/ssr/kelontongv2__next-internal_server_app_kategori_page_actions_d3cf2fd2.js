module.exports = [
"[project]/kelontongv2/.next-internal/server/app/kategori/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_kategori_page_actions_d3cf2fd2.js.map