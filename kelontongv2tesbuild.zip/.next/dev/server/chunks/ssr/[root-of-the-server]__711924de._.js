module.exports = [
"[project]/kelontongv2/src/app/favicon.ico.mjs { IMAGE => \"[project]/kelontongv2/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/kelontongv2/src/app/favicon.ico.mjs { IMAGE => \"[project]/kelontongv2/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/kelontongv2/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/kelontongv2/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/kelontongv2/src/app/riwayat-transaksi/page.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/kelontongv2/src/app/riwayat-transaksi/page.js'\n\nUnterminated regexp literal");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[project]/kelontongv2/src/app/riwayat-transaksi/page.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/kelontongv2/src/app/riwayat-transaksi/page.js [app-rsc] (ecmascript)"));
}),
];