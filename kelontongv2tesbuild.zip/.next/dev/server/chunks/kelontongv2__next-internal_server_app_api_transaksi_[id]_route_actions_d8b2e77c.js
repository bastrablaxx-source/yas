module.exports = [
"[project]/kelontongv2/.next-internal/server/app/api/transaksi/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_api_transaksi_%5Bid%5D_route_actions_d8b2e77c.js.map