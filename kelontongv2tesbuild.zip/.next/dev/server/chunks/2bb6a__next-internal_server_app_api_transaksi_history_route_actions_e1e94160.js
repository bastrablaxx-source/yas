module.exports = [
"[project]/kelontongv2/.next-internal/server/app/api/transaksi/history/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=2bb6a__next-internal_server_app_api_transaksi_history_route_actions_e1e94160.js.map