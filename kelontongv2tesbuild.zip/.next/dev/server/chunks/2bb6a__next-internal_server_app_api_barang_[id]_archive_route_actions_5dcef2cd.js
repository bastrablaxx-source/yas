module.exports = [
"[project]/kelontongv2/.next-internal/server/app/api/barang/[id]/archive/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=2bb6a__next-internal_server_app_api_barang_%5Bid%5D_archive_route_actions_5dcef2cd.js.map