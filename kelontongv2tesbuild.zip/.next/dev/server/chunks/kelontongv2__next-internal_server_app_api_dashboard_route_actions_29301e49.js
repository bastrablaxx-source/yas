module.exports = [
"[project]/kelontongv2/.next-internal/server/app/api/dashboard/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_api_dashboard_route_actions_29301e49.js.map