module.exports = [
"[project]/kelontongv2/.next-internal/server/app/api/me/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_api_me_route_actions_71fa0fd2.js.map