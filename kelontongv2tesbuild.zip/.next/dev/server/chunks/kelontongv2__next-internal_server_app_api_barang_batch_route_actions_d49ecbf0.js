module.exports = [
"[project]/kelontongv2/.next-internal/server/app/api/barang/batch/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kelontongv2__next-internal_server_app_api_barang_batch_route_actions_d49ecbf0.js.map