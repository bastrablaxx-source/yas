globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/55a14_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a5d2188b._.js",
    "static/chunks/55a14_next_dist_compiled_react-dom_d906132b._.js",
    "static/chunks/55a14_next_dist_compiled_react-server-dom-turbopack_0e20b1b5._.js",
    "static/chunks/55a14_next_dist_compiled_next-devtools_index_435c3c2e.js",
    "static/chunks/55a14_next_dist_compiled_9d50e3f9._.js",
    "static/chunks/55a14_next_dist_client_d69053b3._.js",
    "static/chunks/55a14_next_dist_d6dc495c._.js",
    "static/chunks/55a14_@swc_helpers_cjs_1712d2af._.js",
    "static/chunks/kelontongv2_a0ff3932._.js",
    "static/chunks/turbopack-kelontongv2_cb20ff26._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];