var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/barang/search/route.js")
R.c("server/chunks/[root-of-the-server]__6f76b9d8._.js")
R.c("server/chunks/kelontongv2_71496c01._.js")
R.c("server/chunks/[root-of-the-server]__3fb4d6aa._.js")
R.c("server/chunks/[root-of-the-server]__d00444de._.js")
R.c("server/chunks/kelontongv2__next-internal_server_app_api_barang_search_route_actions_3891c117.js")
R.m(41847)
module.exports=R.m(41847).exports
