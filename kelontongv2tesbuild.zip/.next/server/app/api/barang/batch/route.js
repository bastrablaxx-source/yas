var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/barang/batch/route.js")
R.c("server/chunks/[root-of-the-server]__424101ee._.js")
R.c("server/chunks/kelontongv2_71496c01._.js")
R.c("server/chunks/[root-of-the-server]__3fb4d6aa._.js")
R.c("server/chunks/[root-of-the-server]__d00444de._.js")
R.c("server/chunks/kelontongv2__next-internal_server_app_api_barang_batch_route_actions_d49ecbf0.js")
R.m(1366)
module.exports=R.m(1366).exports
