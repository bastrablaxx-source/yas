var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/barang/route.js")
R.c("server/chunks/[root-of-the-server]__fed6069d._.js")
R.c("server/chunks/kelontongv2_71496c01._.js")
R.c("server/chunks/[root-of-the-server]__3fb4d6aa._.js")
R.c("server/chunks/[root-of-the-server]__d00444de._.js")
R.c("server/chunks/kelontongv2__next-internal_server_app_api_barang_route_actions_bb86b658.js")
R.m(63409)
module.exports=R.m(63409).exports
