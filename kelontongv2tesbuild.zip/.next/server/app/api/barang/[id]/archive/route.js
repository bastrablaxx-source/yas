var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/barang/[id]/archive/route.js")
R.c("server/chunks/[root-of-the-server]__69deddd8._.js")
R.c("server/chunks/kelontongv2_71496c01._.js")
R.c("server/chunks/[root-of-the-server]__3fb4d6aa._.js")
R.c("server/chunks/[root-of-the-server]__d00444de._.js")
R.c("server/chunks/2bb6a__next-internal_server_app_api_barang_[id]_archive_route_actions_5dcef2cd.js")
R.m(12524)
module.exports=R.m(12524).exports
