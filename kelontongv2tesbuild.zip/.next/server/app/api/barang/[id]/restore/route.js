var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/barang/[id]/restore/route.js")
R.c("server/chunks/[root-of-the-server]__2bf2a7c3._.js")
R.c("server/chunks/kelontongv2_71496c01._.js")
R.c("server/chunks/[root-of-the-server]__3fb4d6aa._.js")
R.c("server/chunks/[root-of-the-server]__d00444de._.js")
R.c("server/chunks/2bb6a__next-internal_server_app_api_barang_[id]_restore_route_actions_ad588710.js")
R.m(557)
module.exports=R.m(557).exports
