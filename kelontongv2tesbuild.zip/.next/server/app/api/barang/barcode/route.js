var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/barang/barcode/route.js")
R.c("server/chunks/[root-of-the-server]__79a6e322._.js")
R.c("server/chunks/kelontongv2_71496c01._.js")
R.c("server/chunks/[root-of-the-server]__3fb4d6aa._.js")
R.c("server/chunks/[root-of-the-server]__d00444de._.js")
R.c("server/chunks/kelontongv2__next-internal_server_app_api_barang_barcode_route_actions_ec0535d6.js")
R.m(72284)
module.exports=R.m(72284).exports
